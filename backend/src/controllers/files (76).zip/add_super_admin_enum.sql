-- Add SUPER_ADMIN to the EmployeeRole enum
-- Run this in Supabase SQL Editor

ALTER TYPE "EmployeeRole" ADD VALUE IF NOT EXISTS 'SUPER_ADMIN';

-- After running, set your account as SUPER_ADMIN:
-- UPDATE "Employee" SET role = 'SUPER_ADMIN' WHERE code = 'ADMIN001' AND "dairyId" = 1;

SELECT 'SUPER_ADMIN enum value added successfully' AS result;
